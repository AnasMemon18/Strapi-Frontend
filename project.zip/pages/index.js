export default function Home({ products }) {
    console.log("Products: ", products);
  
    return (
      <div>
        <h2>Products</h2>
        <table>
          <thead>
            <tr>
              <th>Username</th>
              <th>Product Name</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product, index) => (
              <tr key={product.id}>
                <td>{product.attributes.users.data[index].attributes.username}</td>
                <td>{product.attributes.product_name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
  
    );
  }
  
  export async function getStaticProps() {
    // Get products from our strapi
    const res = await fetch("http://localhost:1337/api/products?populate=*");
    const data = await res.json();
    const products = data.data;
  
    return {
      props: { products },
    };
  }